module.exports.start = () => {
    require("./app.js");
}