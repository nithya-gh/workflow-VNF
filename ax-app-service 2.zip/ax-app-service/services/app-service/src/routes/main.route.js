const express                     = require('express');

module.exports = (function () {
  	const router = express.Router();
  	router.get("/hello", (req,res)=> {		  
		res.json({ messagee: 'Hello World !!!' })
	});
  	return router;
})();
