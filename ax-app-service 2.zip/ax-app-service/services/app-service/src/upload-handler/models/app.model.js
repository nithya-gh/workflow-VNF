var app = require("@cisco-automationx-platform/mw-util-common-app");
var baseSchemaObj = app.mongodb.bpaBaseSchema();
var mongoose = app.mongodb.getConnection();
var Schema = mongoose.Schema;

var appSchema = new Schema({
  ...baseSchemaObj.obj,
  name: {
    type: String,
    required: 'App name is required'
  },
  bundleName: {
    type: String
  },
  bundleVersion:  {
    type: String
  },
  fileName: {
    type: String,
    required: 'File name is required'
  },
  manifest: {
    type: Object
  },
  fileSize: {
    type: String
  },
  md5Hash: {
    type: String
  },
  status: {
    type: String
  },
  metadata: {
    type: Object
  },
  percentageOfCompletion: {
    type: Number
  },
  dbuser: {
    type: String
  },
  dbpass: {
    type: String
  }
});
appSchema.index({ "name": 1}, { "unique": true });
appSchema.plugin(app.multiTenant.mongoose.plugin);
module.exports = mongoose.model('appSchema', appSchema);
