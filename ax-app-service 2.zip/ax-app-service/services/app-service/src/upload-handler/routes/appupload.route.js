const express = require('express');
const uploadHandlerController = require('../controller/uploadhandler.controller')
var common = require('@cisco-automationx-platform/mw-util-common-app');
const multer = require('multer')
module.exports = {};
module.exports.normalizedAPIs = (() => {
    var router = express.Router();
    var currFile;
    const storage = multer.diskStorage({
        destination: (req, file, cb) => {
            cb(null, '/home/node/app/uploads');
        },
        filename: (req, file, cb) => {
            currFile = file;
            cb(null, file.originalname);
        },
        onError : function(err, next) {
            console.log('error', err);
            next(err);
        }
    });
    const fileFilter = (req, file, cb) => {
        if (file.mimetype === 'application/zip' || file.mimetype === 'application/octet-stream') {
            cb(null, true);
        }
        else {
            cb(null, false);
        }
    }
    const upload = multer({ storage: storage, fileFilter: fileFilter, limits: { fileSize: 5e+9 } });
    router.post('/upload', upload.single('file'), common.wrapVersion(uploadHandlerController.fileUpload, '1.0'));
    return router;
})();