const appSchemaModel = require('../models/app.model')
const { logger } = require('@cisco-automationx-platform/mw-util-common-app');
const app = require('@cisco-automationx-platform/mw-util-common-app')
const path = require('path')
const yaml = require('js-yaml');
const fs = require('fs');
const unzipper = require('unzipper')
const { uniqueNamesGenerator, adjectives, colors, animals } = require('unique-names-generator');
const md5File = require('md5-file')
const CORE_URI = app.services.core.url;
const auditNotification = require('../../helpers/audit-notification.helper')

exports.fileUpload = async function (req, res, next) {
    try {
        let currFile = req.file;
        let currUser = (req.decoded) ? req.decoded.nam : "UnknownUser";
        let currDate = new Date();

        const shortName = uniqueNamesGenerator({
            dictionaries: [adjectives, colors],
            length: 2
        });
        let extractLocation = currFile.destination + "/" + path.parse(currFile.path).name + "_" + Date.now() + "_" + shortName;

        documentInsertCallback = function (manifestJson) {
            let bundleName = manifestJson.bundleName.trim();
            let bundleVersion = manifestJson.bundleVersion.trim();
            let description = manifestJson.description.trim();
            let bundleKey = bundleName.replace(" ", "_") + "_" + shortName
            let fileName = bundleKey + "-" + bundleVersion + ".aab"

            //Rename .zip to .aab
            fs.rename(currFile.path, currFile.destination + "/" + fileName, function (err) {
                if (err) {
                    logger.error("Error in renaming AAB package", err);
                }
            });

            //Remove extracted dir to read aab-manifest.yaml
            fs.rmdirSync(extractLocation, { recursive: true });

            var bundleRecord = {
                localBaseSchema: true,
                name: bundleKey,
                bundleName: bundleName,
                bundleVersion: bundleVersion,
                description: description,
                manifest: manifestJson,
                fileName: fileName,
                fileSize: currFile.size,
                createdBy: currUser,
                createdDate: currDate,
                updatedBy: currUser,
                updatedDate: currDate,
                md5Hash: md5File.sync(currFile.destination + "/" + fileName),
                status: "UPLOADED",
                percentageOfCompletion: 0,
                __tenant: req.tenant
            };
            var currStorageRecord = new appSchemaModel(bundleRecord);
            currStorageRecord.save({ tenant: req.tenant }, function (err, savedData) {
                if (err) {
                    logger.error('Unable to save inbound request.', err);
                    res.status(500).json({ 'msg': 'Unable to save inbound request.' });
                } else {
                    auditNotification.addInfoAudit('AAB upload',`Uploaded App ${bundleKey} successfully`,req.tenant.getCurrentTenantId(),req.tenant.user.nam)
                    logger.debug(`success: true, bundleID: ${savedData._id}, bundleName: ${savedData.name}`);
                    res.status(200).json({ success: true, instanceName: savedData.name, bundleID: savedData._id, bundleName: savedData.bundleName, bundleVersion: bundleVersion });
                }
            });
        }

        try {       
            readManifest(currFile.path, extractLocation, documentInsertCallback)
        } catch (err) {
            logger.error("Error in extracting the zip file", err);
            res.status(400).json({ success: false, msg: err });
            return;
        }
    } catch (error) {
        logger.error(error);
    }
}


async function readManifest(zipPath, manifestDirPath, documentInsertCallback) {
    const zip = fs.createReadStream(zipPath).pipe(unzipper.Parse({ forceStream: true }));
    let manifestLocation;
    let hasManifest = false;
    let manifestJson;
    try {
        for await (const entry of zip) {
            const fileName = entry.path;
            if (fileName.includes("aab-manifest.yaml")) {
                hasManifest = true;
                if (!fs.existsSync(manifestDirPath)) {
                    fs.mkdirSync(manifestDirPath);
                }
                try {
                    manifestLocation = manifestDirPath + '/aab-manifest.yaml'
                    entry.pipe(fs.createWriteStream(manifestLocation)).on('finish', function (err) {
                        manifestJson = yaml.load(fs.readFileSync(manifestLocation, 'utf8'));
                        documentInsertCallback(manifestJson)
                    });
                } catch (err) {
                    logger.error("Cannot create aab-manifest.yaml in the location" + manifestLocation, err)
                    throw err;
                }
                break;
            } else {
                entry.autodrain();
            }
        }
    } catch (err) {
        throw err;
    }
}