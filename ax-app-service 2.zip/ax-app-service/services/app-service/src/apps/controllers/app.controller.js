var appHelper = require('../helpers/app.helper')

exports.getAppList = function (req, res, next) {
    var promise = appHelper.getAppList(req);
    promise.then(response => {
        res.send(response);
    }).catch(err => {
        console.log("Error in getting App list", err);
        res.send([]);
    });
}


exports.modifyApp = function (req, res, next) {
    var promise = appHelper.modifyApp(req);
    promise.then(response => {
        res.json(response);
    }).catch(err => {
        console.log("Error in modifying App", err);
        let status = err.status ? err.status : 500;
        res.status(status).json(errorHandlerObject.errorHandler(false, false, 'Unable to modify app', status));
    });
}

exports.deleteApp = function (req, res, next) {
    var promise = appHelper.deleteApp(req);
    promise.then(response => {
        res.json(response);
    }).catch(err => {
        let status = err.status ? err.status : 500;
        res.status(status).json(errorHandlerObject.errorHandler(false, false, 'Unable to delete app.', status));
    });
}

exports.uninstallApp = function (req, res, next) {
    var promise = appHelper.uninstallApp(req);
    promise.then(response => {
        res.send(response)
    }).catch(err => {
        console.log("Error in uninstalling App", err);
        let status = err.status ? err.status : 500;
        res.status(status).json(errorHandlerObject.errorHandler(false, false, 'Unable to uninstall app', status));
    });
}

exports.getManifest = function (req, res, next) {
    var promise = appHelper.getManifest(req)
    promise.then(response => {
        res.send(response);
    }).catch(err => {
        console.log("Error in getting manifest for App", err);
        let status = err.status ? err.status : 500;
        res.status(status).json(errorHandlerObject.errorHandler(false, false, 'Unable to get manifest for the app', status));
    });
}

exports.installApp = function (req, res, next) {
    var promise = appHelper.installApp(req)
    promise.then(response => {
        res.send(response);
    }).catch(err => {
        console.log("Error in installing App", err);
        let status = err.status ? err.status : 500;
        res.status(status).json(errorHandlerObject.errorHandler(false, false, 'Unable to install app.', status));
    });
}

exports.updateDBCred = function (req, res, next) {
    if(req.body.user === null || req.body.user === undefined) {
        res.status(400).json({message: 'DB user is not provided'});
        return;
    }
    if(req.body.pass === null || req.body.pass === undefined) {
        res.status(400).json({message: 'DB password is not provided'});
        return;
    }
    var promise = appHelper.updateDBCred(req)
    promise.then(response => {
        res.send(response);
    }).catch(err => {
        console.log("Error in updating DB credential", err);
        let status = err.status ? err.status : 500;
        res.status(status).json(errorHandlerObject.errorHandler(false, false, 'Unable to update DB credential.', status));
    });
}

exports.getDBCred = function (req, res, next) {
    var promise = appHelper.getDBCred(req)
    promise.then(response => {
        res.send(response);
    }).catch(err => {
        console.log("Error in getting DB credential", err);
        let status = err.status ? err.status : 500;
        res.status(status).json(errorHandlerObject.errorHandler(false, false, 'Unable to get DB credential.', status));
    });
}
