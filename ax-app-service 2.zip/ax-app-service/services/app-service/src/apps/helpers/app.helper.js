var querySanitizer = require("mongo-sanitize")
var appSchemaModel = require("../../upload-handler/models/app.model")
const errors = require('throw.js');
const appModel = require("../../upload-handler/models/app.model");
var common = require('@cisco-automationx-platform/mw-util-common-app');
const auditNotification = require('../../helpers/audit-notification.helper');

exports.getAppList = function (req) {
    return new Promise(function (resolve, reject) {
        var filter = req.query.filter
        var page = req.query.page
        var limit = req.query.limit
        obj = {}
        if (filter !== undefined && filter.trim() !== '') {
            try {
                filter = JSON.parse(filter)
                obj = querySanitizer(filter)
            } catch (err) {
                return reject(err)
            }
        }
        conditions = { sort: { createdDate: "desc" }, tenant: req.tenant }
        if (page !== undefined && limit !== undefined) {
            page = parseInt(page)
            limit = parseInt(limit)
            if (page > 0 && limit > 0) {
                noOfSkips = limit * (page - 1)
                conditions["skip"] = noOfSkips
                conditions["limit"] = limit
            }
        }
        appSchemaModel.find(obj, { "name": 1, "bundleName": 1, "bundleVersion": 1, "description": 1, "status": 1, "percentageOfCompletion": 1, "_id": 1 }, conditions, function (err, resp) {
            if (err) {
                reject(err);
            }
            return resolve(resp)
        });
    });
}

exports.modifyApp = function (req, res, next) {
    return new Promise(function (resolve, reject) {
        appSchemaModel.findOneAndUpdate({ "_id": req.body.id }, req.body, { tenant: req.tenant }, function (err, savedModel) {
            if (err) {
                reject(err)
            } else if (!appModel) {
                reject(new errors.NotFound(`${req.body.id} - App not found`, 404))
            } else {
                auditNotification.addInfoAudit('AAB Packagge',`Updated App ${req.params.name} successfully`,req.tenant.getCurrentTenantId(),req.tenant.user.nam)
                resolve({ "status": "success", "message": `${req.params.name} - App updated successfully` });
            }
        });
    });
}

exports.deleteApp = function (req) {
    return new Promise(function (resolve, reject) {
        appSchemaModel.findOne({ "_id": req.params.id }, {}, { tenant: req.tenant }, function (err, appModel) {
            if (err) {
                reject(err)
            } else if (!appModel) {
                reject(new errors.NotFound(`${req.params.id} - App not found`, 404))
            } else {
                appSchemaModel.deleteOne({ "_id": req.params.id }, { tenant: req.tenant }, function (err, deletedModel) {
                    if (err) {
                        reject(err)
                    } else {
                        auditNotification.addInfoAudit('AAB Packagge',`Deleted App ${req.params.id} successfully`,req.tenant.getCurrentTenantId(),req.tenant.user.nam)
                        resolve({ "status": "deleted", "message": `${req.params.id} - App is deleted successfully ` })
                    }
                });
            }
        });
    });
}

exports.installApp = function (req) {
    return new Promise(function (resolve, reject) {
        appSchemaModel.findOne({ "_id": req.params.id }, {}, { tenant: req.tenant }, function (err, appModel) {
            if (err) {
                reject(err)
            } else if (!appModel) {
                reject(new errors.NotFound(`${req.params.id} - App not found`, 404))
            } else {
                //TODO: Make API call to app-deployer to install app
                resolve({ "status": "success", "message": `${req.params.id} Installed APP successfully` })
            }
        });
    });
}

exports.uninstallApp = function (req, res, next) {
    return new Promise(function (resolve, reject) {
        appSchemaModel.findOne({ "_id": req.params.id }, {}, { tenant: req.tenant }, function (err, appModel) {
            if (err) {
                reject(err)
            } else if (!appModel) {
                reject(new errors.NotFound(`${req.params.id} - App not found`, 404))
            } else {
                //TODO: Make API call to app-deployer to uninstall app
                auditNotification.addInfoAudit('AAB Packagge',`Uninstall App ${req.params.id} successfully`,req.tenant.getCurrentTenantId(),req.tenant.user.nam)
                resolve({ "status": "success", "message": `Uninstall successfull - ${req.params.id}` })
            }
        });
    });
}

exports.getDBCred = function (req, res, next) {
    return new Promise(function (resolve, reject) {
        appSchemaModel.findOne({ "name": req.params.name }, {}, { tenant: req.tenant }, function (err, appModel) {
            if (err) {
                reject(err)
            } else if (!appModel) {
                reject(new errors.NotFound(`${req.params.name} - App not found`, 404))
            } else {
                let dbUserDecrypt = common.cryption.decryptAES256(appModel.dbuser);
                let dbPassDecrypt = common.cryption.decryptAES256(appModel.dbpass);
                let bufferDBUser = Buffer.from(dbUserDecrypt, "utf8")
                let bufferDBPass = Buffer.from(dbPassDecrypt, "utf8")
                resolve({ username: bufferDBUser.toString('base64'), password: bufferDBPass.toString('base64') })
            }
        });
    });
}

exports.updateDBCred = function (req) {
    return new Promise(function (resolve, reject) {
        let dbUser = Buffer.from(req.body.user, 'base64').toString('utf-8');
        let dbPass = Buffer.from(req.body.pass, 'base64').toString('utf-8');
        let dbUserEncrypt = common.cryption.encryptAES256(dbUser);
        let dbPassEncrypt = common.cryption.decryptAES256(dbPass);
        let payload = {
            "dbuser": dbUserEncrypt,
            "dbpass": dbPassEncrypt
        }
        appSchemaModel.findOneAndUpdate({ "name": req.params.name }, payload, { tenant: req.tenant }, function (err, appModel) {
            if (err) {
                reject(err)
            } else if (!appModel) {
                reject(new errors.NotFound(`${req.params.name} - App not found`, 404))
            } else {
                auditNotification.addInfoAudit('AAB Packagge',`Updated DB credential for App ${req.params.name} successfully`,req.tenant.getCurrentTenantId(),req.tenant.user.nam)
                resolve({ username: appModel.dbuser, password: appModel.dbpass })
            }
        });
    });
}

exports.getManifest = function (req, res, next) {
    return new Promise(function (resolve, reject) {
        appSchemaModel.findOne({ "_id": req.params.id }, {}, { tenant: req.tenant }, function (err, appModel) {
            if (err) {
                reject(err)
            } else if (!appModel) {
                reject(new errors.NotFound(`${req.params.id} - App not found`, 404))
            } else if (appModel.manifest === null || appModel.manifest === undefined) {
                reject(new errors.NotFound(`Manifest for the App ${req.params.id} does not exists`))
            } else {
                resolve(appModel.manifest)
            }
        });
    });
}