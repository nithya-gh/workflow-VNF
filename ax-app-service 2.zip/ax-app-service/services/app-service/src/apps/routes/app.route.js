const express = require('express');
var common = require('@cisco-automationx-platform/mw-util-common-app');
var appController = require('../controllers/app.controller');
module.exports = {};
module.exports.normalizedAPIs = (() => {
    var router = express.Router();
    router.get('/',common.wrapVersion(appController.getAppList, '1.0'))
    router.patch('/',common.wrapVersion(appController.modifyApp, '1.0'))
    router.delete('/:id', common.wrapVersion(appController.deleteApp, '1.0'))
    router.get('/manifest/:id', common.wrapVersion(appController.getManifest, '1.0'))
    router.post('/install/:id', common.wrapVersion(appController.installApp, '1.0'))
    router.post('/uninstall/:id', common.wrapVersion(appController.uninstallApp, '1.0'))
    router.patch('/dbCred/:name', common.wrapVersion(appController.updateDBCred, '1.0'))
    router.get('/dbCred/:name', common.wrapVersion(appController.getDBCred, '1.0'))
    return router;
})();