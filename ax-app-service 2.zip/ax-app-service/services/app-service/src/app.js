var capp = require('@cisco-automationx-platform/mw-util-common-app');
var environment = capp.environment;
const { logger, authMiddleware } = require('@cisco-automationx-platform/mw-util-common-app');
var router = require('./routes/main.route');
var uploadRouter = require('./upload-handler/routes/appupload.route')
var appRouter = require('./apps/routes/app.route')

capp.vault.getEncryptionKey().then(EncryptionKey => {
  capp.debug("Reading EncryptionKey from vault plugin");
  global.encryption_key = EncryptionKey;
  capp.vault.getJWTSecret().then(JWTSecret => {
    capp.debug("Reading JWTSecret from vault plugin");
    global.jwt_secret = JWTSecret;
    initApp();
  }).catch(err => {
    capp.debug('Reading JWTSecret from environment variable because : ' + JSON.stringify(err));
    global.jwt_secret = process.env.JWT_SECRET;
    initApp();
  });
}).catch(err => {
  capp.debug('Reading getEncryptionKey and JWTSecret from environment variable because : ' + JSON.stringify(err));
  global.jwt_secret = process.env.JWT_SECRET;
  global.encryption_key = process.env.ENCRYPTION_KEY;
  initApp();
});

function initApp() {
  var DATABASE_NAME = 'app_db';
  capp.initApp({ 'port': 9220, 'nonsslPort': 9120, 'DATABASE_NAME': DATABASE_NAME, 'DB_CONNECTION_MODE': 'DEFAULT' }, (app) => {
    capp.debug("On After App Initialization.");
    onAfterInit(app);
  });
}

function onAfterInit(app) {
  app.use(authMiddleware.verifyToken);
  app.use("/", router);
  app.use("/api/" + environment.versionRegex, router);
  router.use("/upload-handler", uploadRouter.normalizedAPIs);
  router.use("/app", appRouter.normalizedAPIs)
}