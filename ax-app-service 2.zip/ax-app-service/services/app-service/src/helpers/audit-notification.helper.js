const app = require("@cisco-automationx-platform/mw-util-common-app");
const request = require("request").defaults({ rejectUnauthorized: false });
const CORE_URI = app.services.core.url;

// Audit notification for Info
module.exports.addInfoAudit = (title, description, tenant, user) => {
    return addAuditNotification(title, description,{ severity: 'info' }, tenant, user);
}

// Audit notification for Warning
module.exports.addWarningAudit = (title, description, tenant , user) => {
    return addAuditNotification(title, description, { severity: 'warning' }, tenant, user);
}

const addAuditNotification = (title, description,severityObj, tenant, user) => {
    const promiseFunction = (resolve, reject) => { 
        const args = {
            url: `${CORE_URI}/api/v1.0/event-center/audit-trails`,
            headers: {
                'Content-Type': 'application/json',
                'Connection': 'keep-alive',
                'x-tenant-id' : tenant
            },
            json: [{
                "category": "pipelines.audit.notifications",
                "severity": severityObj.severity,
                "_options": {
                    "audit": true
                },
                "payload": {
                    "title": title,
                    "description": description,
                    "tenant_id": tenant,
                    "user": user
                }
            }]
        };
        request.post(args, (error, response, data = []) => {
            return resolve(data);
        },
            (error, response, body) => {
                app.error("Failed to add Audit notification: ", body);
                return reject(body);
            });
    }
    return new Promise(promiseFunction);
}