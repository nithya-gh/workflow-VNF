rm -rf *.tgz
npm install && npm pack
if [ "$?" -ne "0" ]; then exit 1; fi
if [ ! -f ".npmrc_docker" ]; then
  cp ~/.npmrc .npmrc_docker
fi
docker build -t app-service.local . --no-cache
if [ "$?" -ne "0" ]; then exit 1; fi
